import React from 'react';
import { Route } from 'react-router-dom';

class PokemonDetail extends React.Component { 
    render(){
        return (
            <h1>Detail</h1>
        )
    }
}

export default PokemonDetail;